#!/bin/sh
mkdir $HOME/.ssh
ssh-keygen -f $HOME/.ssh/id_rsa -t rsa -N ""
chmod 700 $HOME/.ssh
mv $HOME/.ssh/id_rsa.pub $HOME/.ssh/authorized_keys

