#!/bin/sh
/tmp/ssh-authkey-create.sh

# execute node2 ssh-authkey-create.sh
expect -c "
set timeout 10
spawn ssh node2
expect \"*(yes/no)? \"
send \"yes\n\"
expect \"*password: \"
send \"oracle\n\"
expect \"$ \"
send \"/tmp/ssh-authkey-create.sh\n\"
expect \"*$ \"
send \"exit\n\"
"

expect -c "
set timeout 10
spawn bash -c \"ssh node2 cat $HOME/.ssh/authorized_keys >> $HOME/.ssh/authorized_keys\"
expect \"*password: \"
send \"oracle\n\"
expect eof
exit
"
expect -c "
set timeout 10
spawn bash -c \"scp $HOME/.ssh/authorized_keys node2:$HOME/.ssh/\"
expect \"*password: \"
send \"oracle\n\"
expect eof
exit
"
ssh-keygen -R node1
ssh-keygen -R node2
ssh-keyscan -H node1 >> ~/.ssh/known_hosts
ssh-keyscan -H node2 >> ~/.ssh/known_hosts
ssh-keyscan -H 192.168.56.101 >> ~/.ssh/known_hosts
ssh-keyscan -H 192.168.56.102 >> ~/.ssh/known_hosts

scp $HOME/.ssh/known_hosts node2:$HOME/.ssh/

