#!/bin/sh
set -x
groupadd -g 54321 oinstall
groupadd -g 54322 dba
groupadd -g 54323 oper
groupadd -g 54324 backupdba
groupadd -g 54325 dgdba
groupadd -g 54326 kmdba
groupadd -g 54327 asmdba
groupadd -g 54328 asmadmin
groupadd -g 54329 asmoper
grep 5432[1-9] /etc/group
useradd -u 54322 -g oinstall -G asmadmin,asmdba,asmoper grid
usermod -u 54321 -g oinstall -G dba,oper,asmdba oracle
echo "oracle" | passwd --stdin grid > /dev/null 2>&1
echo "oracle" | passwd --stdin oracle > /dev/null 2>&1
id grid
id oracle
FILE=/etc/sysctl.conf
echo -e "net.ipv4.conf.enp0s9.rp_filter = 2" >> $FILE
echo -e "net.ipv4.conf.enp0s8.rp_filter = 2" >> $FILE
echo -e "net.ipv4.conf.enp0s3.rp_filter = 1" >> $FILE
sysctl -p 
FILE=/etc/security/limits.conf
echo "@oinstall    soft    nproc    2047" >> $FILE
echo "@oinstall    hard    nproc   16384" >> $FILE
echo "@oinstall    soft    nofile   1024" >> $FILE
echo "@oinstall    hard    nofile  65536" >> $FILE
echo "@oinstall    soft    stack   10240" >> $FILE
echo "@oinstall    hard    stack   10240" >> $FILE
tail -6 $FILE
echo "session required pam_limits.so"|tee -a /etc/pam.d/login
FILE=/etc/profile
echo 'if [ $USER = "oracle" ]; then' >> $FILE
echo '    if [ $SHELL = "/bin/ksh" ]; then' >> $FILE
echo '       ulimit -u 16384' >> $FILE
echo '       ulimit -n 65536' >> $FILE
echo '    else' >> $FILE
echo '       ulimit -u 16384 -n 65536' >> $FILE
echo '    fi' >> $FILE
echo 'fi' >> $FILE
tail -8 $FILE
sed -e 's/^server/#server/g' /etc/chrony.conf -i
echo -e "server 192.168.56.254 iburst" >> /etc/chrony.conf
systemctl restart chronyd.service
chronyc sources
systemctl stop avahi-daemon.socket
systemctl stop avahi-daemon.service
systemctl disable avahi-daemon.socket 2>&1
systemctl disable avahi-daemon.service 2>&1
mkdir -p  /u01/app/18.3.0/grid
mkdir -p /u01/app/grid
mkdir -p /u01/app/oracle/product/18.3.0/dbhome_1
chown -R grid:oinstall /u01
chown -R oracle:oinstall /u01/app/oracle
chmod -R 775 /u01
ls -lR /u01
alias yum2='yum --disablerepo=* --enablerepo=ol7-iso'
yum2 groupinstall -y "Server with GUI" > /dev/null 2>&1
yum2 grouplist installed
yum2 localinstall -y http://192.168.56.254/oracle-database-preinstall-18c-1.0-1.el7.x86_64.rpm > /dev/null 2>&1
yum2 list installed|grep oracle-database
yum2 localinstall -y http://192.168.56.254/cvuqdisk-1.0.10-1.rpm > /dev/null 2>&1
yum2 list installed|grep cvuqdisk
yum clean all > /dev/null 2>&1
fdisk /dev/sdb <<FIN! > /dev/null 2>&1
n
p
1


w
FIN!
fdisk -l /dev/sdb
virsh net-autostart default --disable
virsh net-destroy default
nmcli c mod "System enp0s3" ipv4.dns-search "oracle.com"
nmcli --fields ipv4 connection show 'System enp0s3'|grep ipv4.dns-search
nmcli c down "System enp0s3";nmcli c up "System enp0s3"
nslookup node1
nslookup node2
mount /opt/media
df -h /opt/media

